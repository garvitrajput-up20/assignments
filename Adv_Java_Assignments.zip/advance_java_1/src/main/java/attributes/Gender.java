package attributes;

public enum Gender {
	M, F, U;
}
