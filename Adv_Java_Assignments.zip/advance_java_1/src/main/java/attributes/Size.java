package attributes;

public enum Size {
	S,M,L,XL;
}
