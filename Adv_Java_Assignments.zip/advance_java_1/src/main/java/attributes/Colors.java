package attributes;

public enum Colors {
	BLACK,WHITE,BLUE,PURPLE,GREY,PINK,MAROON,YELLOW;
}
