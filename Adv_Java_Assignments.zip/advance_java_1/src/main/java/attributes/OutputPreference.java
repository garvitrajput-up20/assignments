package attributes;

public enum OutputPreference {
	PRICE,RATING,BOTH;
}
