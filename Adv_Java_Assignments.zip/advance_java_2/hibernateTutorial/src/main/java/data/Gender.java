package data;

public enum Gender {
	M, F, U;

}