package data;

public enum OutputPreference {
	PRICE, RATING, BOTH;
}