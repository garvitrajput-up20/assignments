package data;

public enum Color {
	BLACK, WHITE, BLUE, PURPLE, GREY, PINK, MAROON, YELLOW;
}